"Hello" + "World"
"Hello" - "World"
"Hello" + 3
"Hello" * 3
1 == True、0 == False