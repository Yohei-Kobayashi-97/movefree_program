# 偶数か奇数かの判定するプログラム

# 整数の入力
number = int(input("108:"))

# 偶数： True、 奇数： False
print(number % 2 == 0)