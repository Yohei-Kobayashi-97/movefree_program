print(type(3.14))
print(type("1"))
print(type(True))
print(type([1, 2, "1", "2"]))