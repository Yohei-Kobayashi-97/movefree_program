numbers = [1, 3, 5, 0, 9] #判定対象リスト

if 0 in numbers:
    print("0が含まれています")
else:
    print("0が含まれていません")