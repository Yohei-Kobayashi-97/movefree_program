fruits = {
    "リンゴ": 10,
    "バナナ": 15,
    "オレンジ": 5,
    "ブドウ": 8
}

for name, count in fruits.items():
    print(f"{バナナ}の個数は{count}個です。")