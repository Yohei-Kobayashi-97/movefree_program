x = 1
y = "Hello, Python"

print(x, y)